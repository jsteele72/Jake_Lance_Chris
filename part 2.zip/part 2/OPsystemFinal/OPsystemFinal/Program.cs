﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace OPsystemFinal
{
    class Program
    {
        static void Main(string[] args)
        {
           

            string user = "";
            string ownerPass = "Changeme1";
            string jakePass = "Changeme2";
            string lancePass = "Changeme3";
            string chrisPass = "Changeme4";
            string passAttempt;
            string cmd;
            int domain = -1;
            
            bool access = false;

            do
            {
                // LOG-IN
                Console.Write("Log in as: ");
            user = Console.ReadLine();

            
                switch (user)
                {
                    case "owner":
                        Console.Write("Please enter the password for 'owner': ");
                        passAttempt = Console.ReadLine();

                        if (passAttempt == ownerPass)
                        {
                            Console.WriteLine("Welcome " + user + "!");
                            Console.WriteLine("");
                            access = true;
                            domain = 1;
                        }
                        else
                            Console.WriteLine("Invalid Password!");
                        break;

                    case "guest":
                        Console.WriteLine("Welcome " + user + "!");
                        Console.WriteLine("");
                        access = true;
                        domain = 3;

                        break;

                    case "jake":
                        Console.Write("Please enter the password for 'jake': ");
                        passAttempt = Console.ReadLine();

                        if (passAttempt == jakePass)
                        {
                            Console.WriteLine("Welcome " + user + "!");
                            Console.WriteLine("");
                            access = true;
                            domain = 2;
                        }
                        else
                            Console.WriteLine("Invalid Password!");
                        break;

                    case "lance":
                        Console.Write("Please enter the password for 'jake': ");
                        passAttempt = Console.ReadLine();

                        if (passAttempt == lancePass)
                        {
                            Console.WriteLine("Welcome " + user + "!");
                            Console.WriteLine("");
                            access = true;
                            domain = 2;
                        }
                        else
                            Console.WriteLine("Invalid Password!");
                        break;

                    case "chris":
                        Console.Write("Please enter the password for 'jake': ");
                        passAttempt = Console.ReadLine();

                        if (passAttempt == chrisPass)
                        {
                            Console.WriteLine("Welcome " + user + "!");
                            Console.WriteLine("");
                            access = true;
                            domain = 2;
                        }
                        else
                            Console.WriteLine("Invalid Password!");
                        break;

                    default:
                        Console.WriteLine("Invalid User!");
                        Console.WriteLine("");
                        break;

                }
            } while (access == false);

            Console.WriteLine("Please enter a command. For help enter 'help' to exit enter 'logout': ");
            Console.WriteLine("");

            
            do
            {
                Console.Write(user + "@207.0.0.1$~/ ");
                cmd = Console.ReadLine();
                string[] cmdArr = cmd.Split(' ');


                if (cmdArr[0] == "help")
                {
                    Console.WriteLine("Available Commands: ");
                    Console.WriteLine("'write filename' - Creates a new file or makes changes to an existing file");
                    Console.WriteLine("");
                    Console.WriteLine("'read filename' - Prints the conents of a file in the console if the file exists");
                    Console.WriteLine("");
                    Console.WriteLine("'copy filename destPath' - Copies the file to the specified destinaton");
                    Console.WriteLine("");
                    Console.WriteLine("'delete Path' - Deletes file with specified path");
                    Console.WriteLine("");
                }


                else if (cmdArr[0] == "write")
                {
                    if ((domain == 1) || (domain == 2))
                    {
                        try
                        {
                            System.Diagnostics.Process.Start("notepad.exe", cmdArr[1]);
                        }
                        catch (IndexOutOfRangeException)
                        {
                            Console.WriteLine("please include a file to create or modify");
                            Console.WriteLine("");
                            Console.WriteLine("Command Syntax: 'write filename'");
                        }
                    }
                    else
                        Console.WriteLine("Permission denied");

                }

                else if (cmdArr[0] == "read")
                {


                    try
                    {
                        using (StreamReader readtext = new StreamReader(cmdArr[1]))
                        {
                            string readMeText = readtext.ReadToEnd();
                            Console.WriteLine(readMeText);

                        }
                    }
                    catch (FileNotFoundException)
                    {
                        Console.WriteLine("");
                        Console.WriteLine("The file " + "'" + cmdArr[1] + "'" + " does not exist!");
                    }

                }

                else if (cmdArr[0] == "copy")
                {
                    if (domain == 1 || domain == 2)
                    {


                        System.IO.File.Copy(cmdArr[1], cmdArr[2], true);

                    }
                    else
                        Console.WriteLine("Permission Denied");
                }

                else if (cmdArr[0] == "delete")
                {
                    if (domain == 1)
                    {
                        try
                        {
                            File.Delete(cmdArr[1]);
                        }
                        catch (ArgumentNullException)
                        {
                            Console.WriteLine("Please enter a file path!");
                        }
                        catch (DirectoryNotFoundException)
                        {
                            Console.WriteLine("File not found!");
                        }
                    }
                    else
                        Console.WriteLine("Permission Denied");
                }

                else if (cmdArr[0] == "logout" || cmdArr[0] == "Logout" || cmdArr[0] == "exit" || cmdArr[0] == "Exit")
                {
                    cmd = "logout";
                }

                else
                    Console.WriteLine("Invalid Command!");


                Console.WriteLine("");

              
            }
            while (cmd != "logout");

            /*///////////////////////////////////CONTRIBUTION LOG /////////////////////////////////////
             * 
             * JAKE STEELE- debugging, delete command, help command, minor modifications, linux demo, permissions
             * 
             * LANCE INKENBRANDT- debugging, readme, linux demo, permissions
             * 
             * CHRISTOPHER MATA- debugging, copy command, write command, permissions
             * 
             * 
             * The most difficult part of this project was implementing access matrix.
             * 
             * 
             */
           
        }

    }
}
